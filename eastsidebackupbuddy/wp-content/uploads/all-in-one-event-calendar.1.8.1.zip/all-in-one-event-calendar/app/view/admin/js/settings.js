jQuery( function( $ ) {
	$( '.if-js-closed' ).removeClass( 'if-js-closed' ).addClass( 'closed' );
	postboxes.add_postbox_toggles( ai1ec_settings.page );
});
