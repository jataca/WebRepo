<div class="updated">
	<p>
		<strong>
			<?php echo $msg; ?>
		</strong>
	</p>
</div>