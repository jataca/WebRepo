<?php
//
//  class-ai1ec-invalid-argument.php
//  all-in-one-event-calendar
//
//  Created by The Seed Studio on 2011-07-13.
//

/**
 * Ai1ec_Invalid_Argument class
 *
 * @package Exceptions
 * @author time.ly
 **/
class Ai1ec_Invalid_Argument extends Exception {

}
// END class
