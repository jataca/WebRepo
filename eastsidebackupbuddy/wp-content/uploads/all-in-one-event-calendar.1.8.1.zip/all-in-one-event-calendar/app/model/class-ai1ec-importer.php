<?php
//
//  class-ai1ec-importer.php
//  all-in-one-event-calendar
//
//  Created by The Seed Studio on 2011-07-13.
//

/**
 * Ai1ec_Importer class
 *
 * @package Models
 * @author time.ly
 **/
class Ai1ec_Importer {
	var $events;

	function __construct() {

	}

	function parse_rss( $rss_feed ) {

	}

	function parse_file( $file ) {

	}
}
// END class
