<?php


function render_footer() {
	$builder_link = '<a href="http://ithemes.com/purchase/builder-theme/" title="iThemes Builder">iThemes Builder</a>';
	$ithemes_link = '<a href="http://ithemes.com/" title="iThemes WordPress Themes">iThemes</a>';
	$wordpress_link = '<a href="http://wordpress.org">WordPress</a>';
	
	$footer_credit = sprintf( __( '%1$s by %2$s<br />Powered by %3$s', 'it-l10n-Builder' ), $builder_link, $ithemes_link, $wordpress_link );
	$footer_credit = apply_filters( 'builder_footer_credit', $footer_credit );
	
?>
	<div class="whole">
<a href="http://sandbox.eastsidefriendsofseniors.org/" title="Home">Home</a> &bull; 
<a href="http://sandbox.eastsidefriendsofseniors.org/our-services/" title="Our Services">Our Services</a> &bull; 
<a href="http://sandbox.eastsidefriendsofseniors.org/volunteer/" title="Volunteer">Volunteer</a> &bull; 
<a href="http://sandbox.eastsidefriendsofseniors.org/community-partners/" title="Community Partners">Community Partners</a> &bull; 
<a href="http://sandbox.eastsidefriendsofseniors.org/our-story/" title="Our Story">Our Story</a> &bull; 
<a href="http://sandbox.eastsidefriendsofseniors.org/blog/" title="Blog">Blog</a> &bull; 
<a href="http://sandbox.eastsidefriendsofseniors.org/contact-us/" title="Contact Us">Contact Us</a> &bull; 
<a href="http://sandbox.eastsidefriendsofseniors.org/donate/" title="Donate">Donate</a> &bull; 
<a href="http://sandbox.eastsidefriendsofseniors.org/privacy-policy/" title="Privacy Policy">Privacy Policy</a><br />

<?php bloginfo( 'name' ); ?> <?php printf( __( 'Copyright &copy; %s All Rights Reserved', 'it-l10n-Builder' ), date( 'Y' ) ); ?> &bull; 1121 228th Ave SE, Sammamish WA 98075 &bull; (425) 369-9120<br />
Website Designed by <a href="http://fingerprintmarketing.net/" target="_blank" title="Fingerprint Marketing">FingerprintMarketing.net</a>
	</div>
	<?php wp_footer(); ?>
<?php
	
}

add_action( 'builder_layout_engine_render_footer', 'render_footer' );


?>
