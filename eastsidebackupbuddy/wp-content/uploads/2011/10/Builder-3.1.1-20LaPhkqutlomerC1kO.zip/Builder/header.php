<?php builder_add_doctype(); ?>

<?php builder_add_html_tag(); ?>

<head>

<?php builder_add_charset(); ?>

<?php builder_add_title(); ?>

<?php builder_add_favicon(); ?>

<?php builder_add_stylesheets(); ?>

<?php builder_add_scripts(); ?>

<?php builder_add_meta_data(); ?>

<?php wp_head(); //we need this for plugins ?>

</head>
