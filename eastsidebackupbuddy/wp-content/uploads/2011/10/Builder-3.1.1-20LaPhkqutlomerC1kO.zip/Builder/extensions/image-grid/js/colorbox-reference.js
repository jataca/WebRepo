/*
 *		This file starts the colorbox effect.
 *
 *		Do not delete.
 *
*/
jQuery(document).ready(function(){
	jQuery("a[rel='gallery-images']").colorbox();
});

DD_belatedPNG.fix('.slide_box img, .slide_box, .slide_box a');