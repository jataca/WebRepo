<div class="hentry post">
	<div class="post-title">
		<h3><?php _e( 'Page Not Found', 'it-l10n-Builder' ); ?></h3>
	</div>
	
	<p><?php _e( "We're sorry, but the page you are looking for isn't here.", 'it-l10n-Builder' ); ?></p>
	<p><?php _e( 'Try searching for the page you are looking for or using the navigation in the header or sidebar', 'it-l10n-Builder' ); ?></p>
</div>
