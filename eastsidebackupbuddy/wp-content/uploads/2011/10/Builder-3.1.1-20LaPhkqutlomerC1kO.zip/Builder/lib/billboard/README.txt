Billboard
Premium Ad Management Plugin for WordPress
http://pluginbuddy.com	http://ithemes.com

LICENSE AGREEMENT:
Please read the theme's FAQ page at http://ithemes.com/frequently-asked-questions.

INSTALL:
1. Unpack this archive in your wp-content/plugins/ directory.
2. Go to the WordPress Admin dashboard, and select the Plugins tab.
3. Activate the Billboard plugin.
4. To start using Billboard, it can be found under the Tools menu tab in the WordPress tab.


ONLINE TUTORIALS AND FAQs:

Visit the purchase page to view video tutorials and detailed FAQs for this theme and general WordPress items at the following link:

http://ithemes.com/purchase/billboard-wordpress-ad-manager-plugin/


OTHER ISSUES:

To report bugs or other issues, please e-mail our Support Desk at support@ithemes.com, however most topics are resolved most efficiently on the support boards.

FOR THE BEST SUPPORT AVAILABLE:

We provide full-time support on our support forums please sign up today today at http://forum.ithemes.com.

We typically answer topics from 8:30 a.m.-5:30 p.m. Central Time, Mondays through Fridays, except on major holidays. We make every attempt to respond as quickly as possible, as we realized support issues can pop up at any time.

Support Contact
support@ithemes.com
http://www.ithemes.com

Support Forum
http://forum.ithemes.com/

WordPress Video Tutorials
http://ithemes.com/tutorials/
