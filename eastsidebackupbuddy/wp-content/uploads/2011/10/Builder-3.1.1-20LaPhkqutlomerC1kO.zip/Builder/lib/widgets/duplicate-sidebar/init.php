<?php

/*
Copyright 2010 iThemes (email: support@ithemes.com)

Written by Chris Jean
Version 1.0.0

Version History
	1.0.0 - 2010-10-05 - Chris Jean
		Release-ready
*/


require_once( dirname( __FILE__ ) . '/widget.php' );

?>
