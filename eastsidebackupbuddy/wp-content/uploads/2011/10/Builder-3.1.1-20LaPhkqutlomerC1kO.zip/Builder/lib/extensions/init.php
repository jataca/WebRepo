<?php

/*
Code responsible for loading required parts of the theme
Written by Chris Jean for iThemes.com
Version 1.0.0

Version History
	1.0.0 - 2011-06-29 - Chris Jean
		Release ready
*/


ITUtility::require_file_once( dirname( __FILE__ ) . '/class-builder-extensions.php' );
