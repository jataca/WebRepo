<?php


// Required file to initialize needed variables and load needed code
require_once( dirname( __FILE__ ) . '/lib/builder-core/init.php' );

// Load translations
load_theme_textdomain( 'it-l10n-Builder', dirname( __FILE__ ) . '/lang' );


// Builder features can be modified in a child theme's functions.php by using
// remove_theme_support and the builder_customize_theme_features action.
// The following code snippets are examples of how this can be used.

/*

// Disable Billboard and the Feedburner Widget
function child_theme_remove_theme_features() {
	remove_theme_support( 'builder-billboard' );
	remove_theme_support( 'builder-feedburner-widget' );
}
add_action( 'builder_customize_theme_features', 'child_theme_remove_theme_features' );


// Remove the My Theme menu for everyone but the user with a login of 'admin'
function child_theme_restrict_my_theme_menu() {
	$user = wp_get_current_user();
	
	if ( 'admin' !== $user->user_login )
		remove_theme_support( 'builder-my-theme-menu' );
}
add_action( 'builder_customize_theme_features', 'child_theme_restrict_my_theme_menu' );


// Remove the My Theme menu for everyone but super admins (multisite capability)
function child_theme_restrict_my_theme_menu() {
	if ( ! is_super_admin() )
		remove_theme_support( 'builder-my-theme-menu' );
}
add_action( 'builder_customize_theme_features', 'child_theme_restrict_my_theme_menu' );

*/


// Add support for different theme features
if ( ! function_exists( 'builder_add_theme_features' ) ) {
	function builder_add_theme_features() {
		// Add 2.9+ thumbnail support
		add_theme_support( 'post-thumbnails' );
		
		// Add 3.0+ menu support
		add_theme_support( 'menus' );
		
		// Add links to common RSS feeds
		add_theme_support( 'automatic-feed-links' );
		
		// Add the My Theme menu. If this is removed, the My Theme menu won't show for anyone.
		add_theme_support( 'builder-my-theme-menu' );
		
		// Allow Builder to use file caching to speed up site rendering
		add_theme_support( 'builder-file-cache' );
		
		// Allow Builder to load the the built-in default layouts found in default-layouts.php
		// This should not be disabled unless the child theme specifically provides it's own layouts
		add_theme_support( 'builder-default-layouts' );
		
		// Enable Builder SEO
		// Disabled while code finishes testing
//		add_theme_support( 'builder-seo' );
		
		// Enable support for Builder Extensions
		add_theme_support( 'builder-extensions' );
		
		// Enable the import/export feature
		add_theme_support( 'builder-import-export' );
		
		// Load the Billboard feature found in the DisplayBuddy > Billboard menu
		add_theme_support( 'builder-billboard' );
		
		// Load Feedburner Widget code
		add_theme_support( 'builder-feedburner-widget' );
		
		// Load Duplicate Sidebar widget code
		add_theme_support( 'builder-widget-duplicate-sidebar' );
		
		// Load Widget Content code
		add_theme_support( 'builder-widget-widget-content' );
		
		// Add support for Builder to supply enhancements for specific plugins
		add_theme_support( 'builder-plugin-features' );
		
		// Add support for Widget Styles
		add_theme_support( 'builder-widget-styles' );
		
		// Add support for html5
		add_theme_support( 'html5' );
		
		
		do_action( 'builder_customize_theme_features' );
	}
}
builder_add_theme_features();


// Load the custom-functions.php file if it exists.
if ( file_exists( dirname( __FILE__ ) . '/custom-functions.php' ) )
	ITUtility::require_file_once( dirname( __FILE__ ) . '/custom-functions.php' );
